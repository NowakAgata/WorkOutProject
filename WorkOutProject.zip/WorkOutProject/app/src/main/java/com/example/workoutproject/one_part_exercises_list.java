package com.example.workoutproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class one_part_exercises_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_part_exercises_list);
    }
}
