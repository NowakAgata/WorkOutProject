package com.example.workoutproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class random_exercise_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random_exercise);
    }
}
