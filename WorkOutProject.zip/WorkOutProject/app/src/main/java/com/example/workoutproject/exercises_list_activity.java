package com.example.workoutproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class exercises_list_activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercises_list);

    }

//    public void addNewExercise(View view) {
//        Intent intent = new Intent(getApplicationContext(), new_excercise_activity.class);
//        startActivityForResult(intent, 1);
//    }
}
